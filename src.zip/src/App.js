import logo from './logo.svg';
import './App.css';
import First from './components/first/first';

function App() {
  return (
    <div className="App">
      <p> Iam Sai Shravani </p>
      <br/>
      <First/>
    </div>
  );
}

export default App;
