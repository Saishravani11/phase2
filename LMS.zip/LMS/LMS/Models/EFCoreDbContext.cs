﻿using Microsoft.EntityFrameworkCore;
namespace LMS.Models
{
    public class EFCoreDbContext:DbContext
    {
        public EFCoreDbContext(DbContextOptions<EFCoreDbContext> options) : base(options)
        {
        }
        //OnConfiguring() method is used to select and configure the data source
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employee>().ToTable("Employee");
            modelBuilder.Entity<LeaveHistory>().ToTable("LeaveHistory");
           
        }
       
        public DbSet<Employee> Employs { get; set; }
        public DbSet<LeaveHistory> Leavehistory { get; set; }
    }
}
