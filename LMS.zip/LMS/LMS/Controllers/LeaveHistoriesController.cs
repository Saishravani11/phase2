﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LMS.Models;

namespace LMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LeaveHistoriesController : ControllerBase
    {
        private readonly EFCoreDbContext _context;

        public LeaveHistoriesController(EFCoreDbContext context)
        {
            _context = context;
        }

        // GET: api/LeaveHistories
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LeaveHistory>>> GetLeaveHistories()
        {
            return await _context.Leavehistory.ToListAsync(); // Ensure this matches your DbSet name
        }

        // GET: api/LeaveHistories/5
        [HttpGet("{id}")]
        public async Task<ActionResult<LeaveHistory>> GetLeaveHistory(int id)
        {
            var leaveHistory = await _context.Leavehistory.FindAsync(id);

            if (leaveHistory == null)
            {
                return NotFound();
            }

            return leaveHistory;
        }

        // POST: api/LeaveHistories/apply
        [HttpPost("apply")]
        public async Task<ActionResult<LeaveHistory>> ApplyLeave(LeaveHistory leaveHistory)
        {
            // Validate the leave dates
            if (leaveHistory.LeaveStartDate == default || leaveHistory.LeaveEndDate == default)
            {
                return BadRequest("Leave start date and end date must be provided.");
            }

            if (leaveHistory.LeaveEndDate < leaveHistory.LeaveStartDate)
            {
                return BadRequest("Leave end date must be greater than or equal to leave start date.");
            }

            // Calculate the number of leave days
            leaveHistory.NoOfDays = (leaveHistory.LeaveEndDate - leaveHistory.LeaveStartDate).Days + 1;

            // Add the leave application to the database
            _context.Leavehistory.Add(leaveHistory); // Ensure this matches your DbSet name
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetLeaveHistory), new { id = leaveHistory.LeaveId }, leaveHistory);
        }

        // PUT: api/LeaveHistories/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutLeaveHistory(int id, LeaveHistory leaveHistory)
        {
            if (id != leaveHistory.LeaveId)
            {
                return BadRequest();
            }

            _context.Entry(leaveHistory).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!LeaveHistoryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/LeaveHistories/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLeaveHistory(int id)
        {
            var leaveHistory = await _context.Leavehistory.FindAsync(id);
            if (leaveHistory == null)
            {
                return NotFound();
            }

            _context.Leavehistory.Remove(leaveHistory);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool LeaveHistoryExists(int id)
        {
            return _context.Leavehistory.Any(e => e.LeaveId == id);
        }
    }
}